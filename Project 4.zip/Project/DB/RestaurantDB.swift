//
//  RestaurantDB.swift
//  Project
//
//  Created by Claudia Velasquez on 12/10/17.
//  Copyright © 2017 Claudia Velasquez. All rights reserved.
//

import Foundation
import RealmSwift

class RestaurantDB: Object{
    @objc dynamic var id:String?
    @objc dynamic var name:String?
    @objc dynamic var adress:String?
    @objc dynamic var phone:String?
    @objc dynamic var photo:NSData? // representa una imagen de tipo binario
    @objc dynamic var latitude:Double = 0
    @objc dynamic var longitude:Double = 0
    
    override static func primaryKey() -> String?{
        return "id"
    }
}
