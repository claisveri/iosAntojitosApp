//
//  Restaurant.swift
//  Project
//
//  Created by Claudia Velasquez on 12/10/17.
//  Copyright © 2017 Claudia Velasquez. All rights reserved.
//

import Foundation
import UIKit

class Restaurant {
    var name: String
    var adress: String
    var longitud: String
    var latitud: String
    var phone: String
    var logo: UIImage?
    init?(name:String, adress:String,longitud:String,latitud:String,phone:String,logo:UIImage?){
        self.name = name
        self.adress = adress
        self.longitud = longitud
        self.latitud = latitud
        self.phone = phone
        self.logo = logo
        
        if(name.isEmpty || adress.isEmpty){
            return nil
        }
    }
    
    
}
