//
//  RegisterController.swift
//  Project
//
//  Created by Claudia Velasquez on 12/10/17.
//  Copyright © 2017 Claudia Velasquez. All rights reserved.
//

import UIKit

class RegisterController: UIViewController, UITextFieldDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var restaurantNameTxt: UITextField!
    
    @IBOutlet weak var direccionLabel: UILabel!
    @IBOutlet weak var direccionTxt: UITextField!
    
    @IBOutlet weak var telefonoLabel: UILabel!
    @IBOutlet weak var telefonoTxt: UITextField!
    
    @IBOutlet weak var logotipoLabel: UILabel!
    @IBOutlet weak var logoImg: UIImageView!
    
    
    @IBOutlet weak var saveButton: UIButton!
    @IBOutlet weak var cancelButton: UIButton!
   
     var restaurante:Restaurant?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        restaurantNameTxt.delegate = self
        
        if let restaurante = restaurante {
            self.restaurantNameTxt.text = restaurante.name
            self.direccionTxt.text = restaurante.adress
            self.telefonoTxt.text = restaurante.phone
            self.logoImg.image = restaurante.logo
            
        }

        // Do any additional setup after loading the view.
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        // Hide the keyboard.
        textField.resignFirstResponder()
        return true
    }
    
       
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func selectImageFromPhotoLibrary(_ sender: UITapGestureRecognizer) {
        // Hide the keyboard.
       restaurantNameTxt.resignFirstResponder()
        
        // UIImagePickerController is a view controller that lets a user pick media from their photo library.
        let imagePickerController = UIImagePickerController()
        
        // Only allow photos to be picked, not taken.
        imagePickerController.sourceType = .photoLibrary
        
        // Make sure ViewController is notified when the user picks an image.
        imagePickerController.delegate = self
        present(imagePickerController, animated: true, completion: nil)
    
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        // The info dictionary may contain multiple representations of the image. You want to use the original.
        guard let selectedImage = info[UIImagePickerControllerOriginalImage] as? UIImage else {
            fatalError("Expected a dictionary containing an image, but was provided the following: \(info)")
        }
        
        // Set photoImageView to display the selected image.
       logoImg.image = selectedImage
        
        // Dismiss the picker.
        dismiss(animated: true, completion: nil)
    }
    

}
